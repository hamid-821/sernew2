/* 🔧 فیکس پرش صفحه در چت (ایجنت + گفت‌وگوی کاربر)
   علت: باندل اصلی روی هر پیام جدید scrollIntoView({behavior:"smooth"}) صدا می‌زند
   که همهٔ اجداد اسکرولی از جمله خود صفحه را تکان می‌دهد.
   راه‌حل: فقط کادر چت اسکرول شود، نه کل صفحه. */
(function () {
  "use strict";
  if (window.__gamifyScrollFix) return;
  window.__gamifyScrollFix = true;

  function isChatEl(el) {
    try {
      if (!el || !el.closest) return false;
      return !!el.closest(
        '[class*="chat"],[class*="Chat"],[class*="message"],[class*="Message"],[class*="assistant"],[class*="Assistant"],[data-chat-scroll],textarea,input[type="text"]'
      );
    } catch (e) { return false; }
  }

  function nearestScrollable(el) {
    try {
      var p = el && el.parentElement;
      while (p && p !== document.body && p !== document.documentElement) {
        var s = window.getComputedStyle(p);
        if ((s.overflowY === "auto" || s.overflowY === "scroll" || s.overflow === "auto") && p.scrollHeight > p.clientHeight + 8) return p;
        p = p.parentElement;
      }
    } catch (e) {}
    return null;
  }

  // ۱) بازنویسی scrollIntoView برای عناصر داخل چت
  try {
    var origSIV = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function (arg) {
      try {
        if (isChatEl(this)) {
          var box = nearestScrollable(this);
          if (box) {
            var behavior = arg && typeof arg === "object" && arg.behavior ? arg.behavior : "smooth";
            // فقط کادر چت به آخر برود
            box.scrollTo({ top: box.scrollHeight, behavior: behavior });
            return;
          }
          // بدون کادر مشخص: nearest تا صفحه نپرد
          if (arg && typeof arg === "object") {
            return origSIV.call(this, { behavior: arg.behavior || "smooth", block: "nearest", inline: "nearest" });
          }
          return origSIV.call(this, { behavior: "smooth", block: "nearest", inline: "nearest" });
        }
      } catch (e) {}
      return origSIV.apply(this, arguments);
    };
  } catch (e) {}

  // ۲) فوکوس ورودی چت نباید صفحه را بپراند
  try {
    var origFocus = HTMLElement.prototype.focus;
    HTMLElement.prototype.focus = function (opts) {
      try {
        if (this && this.closest && isChatEl(this)) {
          if (opts === undefined) return origFocus.call(this, { preventScroll: true });
          if (typeof opts === "object" && opts !== null && opts.preventScroll === undefined) {
            var o = {}; for (var k in opts) o[k] = opts[k];
            o.preventScroll = true;
            return origFocus.call(this, o);
          }
        }
      } catch (e) {}
      return origFocus.apply(this, arguments);
    };
  } catch (e) {}

  // ۳) نگهبان اسکرول صفحه: اگر هم‌زمان با افزوده‌شدن پیام، صفحه بیش از حد پرید، برگردان
  var lastWinY = window.scrollY || 0;
  var guardUntil = 0;
  window.addEventListener("scroll", function () {
    if (Date.now() < guardUntil) {
      // اگر پرش بزرگ و ناگهانی بود (بیش از ۳۰۰ پیکسل در کسری از ثانیه) برگردان
      var dy = Math.abs(window.scrollY - lastWinY);
      if (dy > 300) {
        try { window.scrollTo({ top: lastWinY, behavior: "auto" }); } catch (e) { window.scrollTo(0, lastWinY); }
        return;
      }
    }
    lastWinY = window.scrollY || 0;
  }, { passive: true });

  // هر وقت در چت تایپ/ارسال شد، ۱.۵ ثانیه نگهبانی کن
  document.addEventListener("submit", function (e) {
    try { if (isChatEl(e.target)) { lastWinY = window.scrollY || 0; guardUntil = Date.now() + 1500; } } catch (err) {}
  }, true);
  document.addEventListener("keydown", function (e) {
    try {
      if (e.key === "Enter" && isChatEl(e.target)) { lastWinY = window.scrollY || 0; guardUntil = Date.now() + 1500; }
    } catch (err) {}
  }, true);
  document.addEventListener("click", function (e) {
    try {
      var t = e.target && e.target.closest ? e.target.closest("button") : null;
      if (t && isChatEl(t)) { lastWinY = window.scrollY || 0; guardUntil = Date.now() + 1500; }
    } catch (err) {}
  }, true);

  // ۴) CSS کمکی: جلوگیری از scroll-anchoring داخل چت + اسکرول نرم فقط برای کادر
  function injectCss() {
    if (document.getElementById("gamify-scroll-fix-css")) return;
    var st = document.createElement("style");
    st.id = "gamify-scroll-fix-css";
    st.textContent = [
      '[class*="chat"] *,[class*="Chat"] *,[class*="message"] *,[class*="Message"] *{overflow-anchor:none!important;}',
      'textarea,input{scroll-margin:0!important;}',
      '#root{overflow-anchor:auto;}'
    ].join("\n");
    (document.head || document.documentElement).appendChild(st);
  }
  if (document.head) injectCss();
  else document.addEventListener("DOMContentLoaded", injectCss);

  console.log("%c[gamify] scroll-fix فعال شد ✅", "color:#7cd7b6");
})();
